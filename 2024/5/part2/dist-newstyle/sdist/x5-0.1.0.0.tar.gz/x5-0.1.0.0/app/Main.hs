import qualified Data.HashMap as HM


main :: IO ()
main = do
  contents <- lines <$> readFile "testInput.txt"
  let rules = takeWhile (/="") contents
  let updates = tail $ dropWhile (/="") contents
  let hm = HM.fromList [(1, [10,20,30])]
  print hm
