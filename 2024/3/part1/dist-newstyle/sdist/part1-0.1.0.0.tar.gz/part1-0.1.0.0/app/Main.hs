import System.IO
import Control.Monad
import Data.List
import Text.Regex.TDFA ((=~), getAllTextMatches, AllTextMatches)
import Text.Regex.TDFA.Text ()

extractMatches :: String -> [String]
extractMatches str = getAllTextMatches (str =~ "mul(.\\d.,\\d.)" :: AllTextMatches [] String)

main = do
  contents <- readFile "input.txt"
  let matches = extractMatches contents
  print matches

